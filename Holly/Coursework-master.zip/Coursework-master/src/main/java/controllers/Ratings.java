package controllers;

public class Ratings {
}
